import java.util.List;

public interface MoveStrategy
{
   void process(List<MoveableShape> shapes);
}
